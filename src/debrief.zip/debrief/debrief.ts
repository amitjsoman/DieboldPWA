import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SiebellibProvider } from '../../providers/siebellib/siebellib';
import { FetchPouchProvider } from '../../providers/fetch-pouch/fetch-pouch';
/**
 * Generated class for the DebriefPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-debrief',
  templateUrl: 'debrief.html',
})
export class DebriefPage {
  timeRecords: any;
  expenseRecords: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,public sieblib: SiebellibProvider,public fetchPouch: FetchPouchProvider) {
    let temp = this;
    /*sieblib.setProfileAttr([{"ACTDETAIL": "1-B0XGY68"}])
      .subscribe((data) => {
        if(data == "ok"){*/
          sieblib.getdata("debrief", "[Activity Id] = '1-B0XGY68'")
            .subscribe((data) => {
              temp.refreshTime();
            });
          /*}
        },(error) => {
        console.log(error);
      });*/
  }

  public refreshTime(){
    let temp = this;
    this.fetchPouch.debriefSubscription
    .subscribe((value) => {
        temp.timeRecords = value;
      console.log(temp.timeRecords);
    },(error) => {
      console.log(error);
    },(complete) => {
      console.log("completed");
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DebriefPage');
  }

}
